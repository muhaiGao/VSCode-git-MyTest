#ifndef _COMMON_H_
#define _COMMON_H_

#include "typedef.h"
#include "BH66F2660.h"
#include "..\BH66F26x0_BodyFat_SDK\SDK_Interface.h"
#include "BodyFat_R.h"
#include "BH66F26x0_UART.h"
#include "User_Protocol.h"
#endif
